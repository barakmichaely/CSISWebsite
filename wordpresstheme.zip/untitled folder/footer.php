
      </div> <!-- #wrap -->
      <footer class ="footer">
        
        <nav class="site-nav">
        
        <hr size="30">
         
       <?php wp_nav_menu( array( 'theme_location' => 'footer-menu'));?>

        </nav>

       </footer>
      </div> <!-- /container -->
    
        <?php wp_footer(); ?>

      </body>

</div>

</div>

</html>